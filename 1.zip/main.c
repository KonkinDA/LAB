#include <stdio.h>
int main(void) {
  int a, b, S, P;
  printf("Введите стороны a и b \n");
  scanf("%d", &a);
  scanf("%d", &b);
  S = a*b;
  P = 2*(a+b);
  printf("Площадь = %d\n", S);
  printf("Периметр = %d", P);
  return 0;
}